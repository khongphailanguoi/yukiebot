import { GoogleGenerativeAI } from "@google/generative-ai"

// Configure the Google Generative AI client
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY || "")

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Validate API key
    if (!process.env.GOOGLE_API_KEY) {
      return Response.json({ error: "GOOGLE_API_KEY is not configured" }, { status: 500 })
    }

    // Format messages for Gemini
    const formattedMessages = messages.map((msg) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.content }],
    }))

    // Get the model
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" })

    // Start a chat session
    const chat = model.startChat({
      history: formattedMessages.slice(0, -1),
      generationConfig: {
        maxOutputTokens: 1000,
      },
    })

    // Get the last user message
    const lastMessage = formattedMessages[formattedMessages.length - 1]

    // Send the message to Gemini and get the response
    const result = await chat.sendMessage(lastMessage.parts[0].text)
    const responseText = result.response.text()

    // Return the response in the format expected by the Vercel AI SDK
    return Response.json({
      id: Date.now().toString(),
      object: "chat.completion",
      created: Date.now(),
      model: "gemini-1.5-flash",
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: responseText,
          },
          finish_reason: "stop",
        },
      ],
    })
  } catch (error) {
    console.error("Error in chat API:", error)
    return Response.json(
      {
        error: "Failed to process chat request",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
